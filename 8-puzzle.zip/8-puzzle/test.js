 var nodo =[];
 var nodo0 = {
	matriz :[[1,2,3],[1,2,3]],
	f: 11,
	g: 2,
	ret: "asdasd"
};
 var nodo1 = {
	matriz :[[1,2,3],[1,2,3]],
	f: 45,
	g: 2,
	ret: "asdasd"
};
 var nodo2 = {
	matriz :[[1,2,3],[1,2,3]],
	f: 1,
	g: 3,
	ret: "asdasd"
};
 var nodo3 = {
	matriz :[[1,2,3],[1,2,3]],
	f: 7123,
	g: 7,
	ret: "asdasd"
};
 var nodo4 = {
	matriz :[[1,2,3],[1,2,3]],
	f: 4,
	g: 21,
	ret: "asdasd"
};


nodo.push(nodo0);
nodo.push(nodo1);
nodo.push(nodo2);
nodo.push(nodo3);
nodo.push(nodo4);

 var numeros = [];
for (var i =0; i < nodo.length; i++) {
	numeros.push(nodo[i].f);
	console.log(numeros, nodo[i].f);
};
console.log(numeros);

var ordenados = (JSON.parse(JSON.stringify(numeros))); 
ordenados.sort((function(a, b){return a-b}));

// console.log(nodo[0]);
console.log(ordenados);
console.log(numeros);
console.log(numeros.indexOf(ordenados[0]));
console.log(numeros[0]);






